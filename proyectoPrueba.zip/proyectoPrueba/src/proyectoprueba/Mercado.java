/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyectoprueba;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author alvar
 */
public class Mercado implements Serializable{

    public  List<Jugador> mercado;
    
    public Mercado(){
        mercado = new ArrayList();
        
    }
    public void setMercado(List e){
        mercado=e;
    }

    public  List<Jugador> getMercado() {
        return mercado;
    }

    public  void a�adirJugador(Jugador j) {
        mercado.add(j);
    }
    public  void eliminarJugador(Jugador j){
        mercado.remove(j);
    }
    
     public  Jugador getJugador(Integer e){
        return mercado.get(e);
    }

     public  void guardarDatos() {
        try {
            ObjectOutputStream salida = new ObjectOutputStream(new FileOutputStream("mercado.bin"));
            salida.writeObject(this);
            salida.close();
         } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static Mercado cargarDatos() {
        Mercado mercado=null;
        try {
            ObjectInputStream entrada = new ObjectInputStream(new FileInputStream("mercado.bin"));
            mercado = (Mercado)entrada.readObject();
            entrada.close();
         } catch (IOException | ClassNotFoundException e) {
            System.out.println("Error al cargar los datos del mercado: " + e.getMessage());
            
        }
        return mercado;
    }

  
    
    
    

}
