/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyectoprueba;

import java.util.Comparator;

/**
 *
 * @author majemase
 */
public class ComparadorPorPuntos implements Comparator {

    @Override
    public int compare(Object o1, Object o2) {
        Equipo otro1 = (Equipo)o1;
        Equipo otro2 = (Equipo)o2;
            int devolver=0;
        if (otro1.getPuntos()>otro2.getPuntos()) {
            devolver=-1;
        }else{
            devolver=1;
        }
        return devolver;
    }
    
}
