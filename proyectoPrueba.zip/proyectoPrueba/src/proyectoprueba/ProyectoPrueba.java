/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package proyectoprueba;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author alvar
 */
public class ProyectoPrueba {
    public static Equipo barsa;
    public static Equipo madrid;
    public static Equipo betis;

      /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Mercado mercado = new Mercado();
        Liga champions = new Liga();
        barsa = new Equipo("barsa");
        betis = new Equipo("betis");
        madrid = new Equipo("madrid");
        madrid.ficharJugador(new Jugador(1874, "madrida", "", "", 50));
        madrid.ficharJugador(new Jugador(1874, "madridb", "", "", 87));
        madrid.ficharJugador(new Jugador(1874, "madridc", "", "", 63));
        madrid.ficharJugador(new Jugador(1874, "madridd", "", "", 97));
        madrid.ficharJugador(new Jugador(1874, "madride", "", "", 72));
        madrid.ficharJugador(new Jugador(1874, "madridf", "", "", 69));
        madrid.ficharJugador(new Jugador(1874, "madridg", "", "", 51));
        madrid.ficharJugador(new Jugador(1874, "madridh", "", "", 68));
        madrid.ficharJugador(new Jugador(1874, "madridi", "", "", 86));
        madrid.ficharJugador(new Jugador(1874, "madridj", "", "", 70));
        madrid.ficharJugador(new Jugador(1874, "madridk", "", "", 48));
        
        betis.ficharJugador(new Jugador(14577, "betisa", "", "", 73));
        betis.ficharJugador(new Jugador(14577, "betisb", "", "", 100));
        betis.ficharJugador(new Jugador(14577, "betisc", "", "", 91));
        betis.ficharJugador(new Jugador(14577, "betisd", "", "", 82));
        betis.ficharJugador(new Jugador(14577, "betise", "", "", 89));
        betis.ficharJugador(new Jugador(14577, "betisf", "", "", 61));
        betis.ficharJugador(new Jugador(14577, "betisg", "", "", 61));
        betis.ficharJugador(new Jugador(14577, "betish", "", "", 84));
        betis.ficharJugador(new Jugador(14577, "betisi", "", "", 77));
        betis.ficharJugador(new Jugador(14577, "betisj", "", "", 100));
        betis.ficharJugador(new Jugador(14577, "betisk", "", "", 73));
        
        barsa.ficharJugador(new Jugador(12003, "barsaa", "", "", 100));
        barsa.ficharJugador(new Jugador(12003, "barsab", "", "", 61));
        barsa.ficharJugador(new Jugador(12003, "barsac", "", "", 77));
        barsa.ficharJugador(new Jugador(12003, "barsad", "", "", 57));
        barsa.ficharJugador(new Jugador(12003, "barsae", "", "", 58));
        barsa.ficharJugador(new Jugador(12003, "barsaf", "", "", 77));
        barsa.ficharJugador(new Jugador(12003, "barsag", "", "", 84));
        barsa.ficharJugador(new Jugador(12003, "barsah", "", "", 61));
        barsa.ficharJugador(new Jugador(12003, "barsai", "", "", 99));
        barsa.ficharJugador(new Jugador(12003, "barsaj", "", "", 57));
        barsa.ficharJugador(new Jugador(12003, "barsak", "", "", 61));
        
        Jugador a = new Jugador(10900, "Daniel", "Polako", "Polaking", 99);
        Jugador b = new Jugador(9600, "Francisco", "Carrero", "NovioZeca", 86);
        Jugador c = new Jugador(8500, "Josema", "Zeca", "NovioCarrero", 75);
        Jugador d = new Jugador(9000, "Paco", "Balon", "Monton de bien", 80);
        Jugador e = new Jugador(9800, "Deivison", "Buenos", "D�as", 88);
        Jugador f = new Jugador(11000, "Valentin", "Rodilla", "Facil", 100);
        Jugador g = new Jugador(9000, "Alvaro", "Como", "Programa", 80);
        Jugador h = new Jugador(4500, "Casandra", "Farmea", "Valentin", 35);
        Jugador i = new Jugador(4500, "Lucia", "Vivero", "Fernandez", 35);
        Jugador j = new Jugador(8000, "Arriola", "Presidente de", "Camas", 70);
        Jugador k = new Jugador(7000, "Danil", "Tiene", "Beca", 60);
        Jugador l = new Jugador(8000, "Ismael", "Presidente", "Espa�a", 70);
        Jugador m = new Jugador(8500, "Marco", "Lucas", "Quesos", 75);
        Jugador n = new Jugador(8000, "Raquel", "Puerto", "Martinez", 70);
        Jugador � = new Jugador(7800, "Paula", "Silvia", "Rojo", 68);
        Jugador o = new Jugador(6000, "Alejandro", "Garcia", "Gutierrez", 50);
        Jugador p = new Jugador(8000, "Majemase", "Jes�s", "Jesusito", 70);
        Jugador q = new Jugador(6000, "Antonio", "Vladimir", "Linux", 50);
        Jugador r = new Jugador(10000, "Eso es", "Asi", "Bro", 90);
        Jugador s = new Jugador(10900, "Chicos", "Cambiamos de", "Tercio", 99);
        Jugador t = new Jugador(11000, "Icono", "Super", "Prime", 100);
        Jugador u = new Jugador(9000, "Javier", "Sevilla", "Wena", 80);
        Jugador v = new Jugador(9000, "Juan", "Antonio", "Redes", 80);
        Jugador w = new Jugador(9000, "Perales", "Presidente", "DAW", 80);
        mercado.a�adirJugador(a);
        mercado.a�adirJugador(b);
        mercado.a�adirJugador(c);
        mercado.a�adirJugador(d);
        mercado.a�adirJugador(e);
        mercado.a�adirJugador(f);
        mercado.a�adirJugador(g);
        mercado.a�adirJugador(h);
        mercado.a�adirJugador(i);
        mercado.a�adirJugador(j);
        mercado.a�adirJugador(k);
        mercado.a�adirJugador(l);
        mercado.a�adirJugador(m);
        mercado.a�adirJugador(n);
        mercado.a�adirJugador(�);
        mercado.a�adirJugador(o);
        mercado.a�adirJugador(p);
        mercado.a�adirJugador(q);
        mercado.a�adirJugador(r);
        mercado.a�adirJugador(s);
        mercado.a�adirJugador(t);
        mercado.a�adirJugador(u);
        mercado.a�adirJugador(v);
        mercado.a�adirJugador(w); 
        List<Equipo> laliga = new ArrayList<>();
        laliga.add(barsa);
        laliga.add(betis);
        laliga.add(madrid);
        champions.setEquipos(laliga);
        mercado.guardarDatos();
        barsa.setMediaEquipo(barsa.getJugadores());
        madrid.setMediaEquipo(madrid.getJugadores());
        betis.setMediaEquipo(betis.getJugadores());
        Equipo.guardarDatos(barsa);
        Equipo.guardarDatos(betis);
        Equipo.guardarDatos(madrid);
        champions.guardarDatos();
        new Swing(champions,barsa,madrid,betis).setVisible(true);

    }

}
