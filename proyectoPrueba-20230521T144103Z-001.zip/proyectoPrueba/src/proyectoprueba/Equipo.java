/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyectoprueba;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 *
 * @author alvar
 */
public class Equipo implements Serializable, Comparable {

    private String nombre;
    private int presupuesto = 800000;
    private  List<Jugador> jugadores;
    private int mediaEquipo = 0;
    private int puntos = 0;

    public Equipo() {
        jugadores = new ArrayList();
    }

    public void setPresupuesto(int presupuesto) {
        this.presupuesto = presupuesto;
    }

    public Equipo(String nombre) {
        this.nombre = nombre;
        jugadores = new ArrayList();
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getNombre() {
        return nombre;
    }

    public int getPresupuesto() {
        return presupuesto;
    }

    public int getPuntos() {
        return puntos;
    }

    public void setPuntos(int puntos) {
        this.puntos = puntos;
    }

    public int getMediaEquipo() {
        return mediaEquipo;
    }

    public void setMediaEquipo(List<Jugador> e) {
        int media = 0;
        int redondeo;
        for (Jugador jugador : e) {
            media = media + jugador.getMedia();
        }
        media = media / 11;
        redondeo = Math.round(media);
        this.mediaEquipo = redondeo;
    }

    public void ficharJugador(Jugador e) {
        jugadores.add(e);
        this.presupuesto = presupuesto - e.sueldo;
        if (this.presupuesto <= 0) {
            rescindirContrato(e);
        }

    }

    public void rescindirContrato(Jugador e) {
        int eliminar = jugadores.indexOf(e);
        jugadores.remove(eliminar);
        this.presupuesto = presupuesto + (int) (e.sueldo * 0.8);

    }

    public int numeroJugadores() {
        return jugadores.size();
    }

    public void entrenamiento() {
        Random rand = new Random();
        double entrenamiento = rand.nextDouble(2) + 1;
        Double media = mediaEquipo * entrenamiento;
        int mediaEntera = (int) Math.round(media);
        mediaEquipo = mediaEntera + mediaEquipo;
        presupuesto = presupuesto - 100000;
    }

    public List<Jugador> getJugadores() {
        return jugadores;
    }

    public Jugador getJugador(Integer e) {
        return jugadores.get(e);
    }

    public static void guardarDatos(Equipo equipo) {
        try {
            ObjectOutputStream salida = new ObjectOutputStream(new FileOutputStream("equipo.bin"));
            salida.writeObject(equipo);
            salida.close();
        } catch (IOException e) {
            System.out.println("Error al guardar los datos del equipo: " + e.getMessage());
        }
    }

    public static Equipo cargarDatos() {
        Equipo equipo = null;
        try {
            ObjectInputStream entrada = new ObjectInputStream(new FileInputStream("equipo.bin"));
            equipo = (Equipo) entrada.readObject();
            entrada.close();
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("Error al cargar los datos del equipo: " + e.getMessage());

        }
        return equipo;
    }

    public int calcularGolesMarcados() {
        
        Random rand = new Random();
        int golesBase = rand.nextInt(4) + 1; 
        return golesBase + (mediaEquipo/ 20); 
    }

    public int calcularGolesRecibidos() {
        Random rand = new Random();
        int golesBase = rand.nextInt(3) + 1; 
        return golesBase - (mediaEquipo / 30); 
    }

    public static String jugarPartido(Equipo equipoLocal, Equipo equipoRival) {
        
        int golesEquipo1 = equipoLocal.calcularGolesMarcados();
        int golesEquipo2 = equipoRival.calcularGolesMarcados();
        Partido partido = new Partido(equipoLocal, equipoRival, golesEquipo1, golesEquipo2);
        if (golesEquipo1 > golesEquipo2) {
            equipoLocal.setPuntos(equipoLocal.getPuntos()+3)  ; 
            equipoLocal.setPresupuesto(equipoLocal.getPresupuesto()+200000);
        } else if (golesEquipo1 < golesEquipo2) {
            
            equipoRival.setPuntos(equipoRival.getPuntos() + 3); 
            equipoRival.setPresupuesto(equipoRival.getPresupuesto() + 200000);
        } else {
            
            equipoLocal.setPuntos(equipoLocal.getPuntos()+1)  ; 
            equipoLocal.setPresupuesto(equipoLocal.getPresupuesto()+100000);
            equipoRival.setPuntos(equipoRival.getPuntos() + 1);
            equipoRival.setPresupuesto(equipoRival.getPresupuesto() + 100000);
        }
        String devolver = golesEquipo1 + " " + golesEquipo2;
        return devolver;
    }

    @Override
    public String toString() {
        return nombre + ": " + puntos;
    }

    @Override
    public int compareTo(Object o) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

}
