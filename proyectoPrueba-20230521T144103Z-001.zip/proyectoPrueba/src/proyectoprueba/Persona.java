/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyectoprueba;

import java.io.Serializable;

/**
 *
 * @author alvar
 */
public class Persona implements Serializable{

    protected String nombre;
    protected String Apellido1;
    protected String Apellido2;
    

    public Persona(String nombre, String Apellido1, String Apellido2) {
        this.nombre = nombre;
        this.Apellido1 = Apellido1;
        this.Apellido2 = Apellido2;
       
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido1() {
        return Apellido1;
    }

    public void setApellido1(String Apellido1) {
        this.Apellido1 = Apellido1;
    }

    public String getApellido2() {
        return Apellido2;
    }

    public void setApellido2(String Apellido2) {
        this.Apellido2 = Apellido2;
    }

    

    @Override
    public String toString() {
        return nombre +" "+ Apellido1+ " "+ Apellido2;
    }

}