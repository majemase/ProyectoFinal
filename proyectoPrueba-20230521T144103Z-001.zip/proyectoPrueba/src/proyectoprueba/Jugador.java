/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyectoprueba;

import java.io.Serializable;

/**
 *
 * @author alvar
 */
public class Jugador extends Persona implements Comparable, Serializable {

    protected int sueldo;
        private int media;

    public Jugador(int sueldo, String nombre, String Apellido1, String Apellido2, int media) {
        super(nombre, Apellido1, Apellido2);
        this.sueldo = sueldo;
        this.media = media;

    }

    public int getMedia() {
        return media;
    }

    public int getSueldo() {
        return sueldo;
    }

    public void setSueldo(int sueldo) {
        this.sueldo = sueldo;
    }

    @Override
    public String getNombre() {
        return nombre;
    }

    @Override
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    @Override
    public String getApellido1() {
        return Apellido1;
    }

    @Override
    public void setApellido1(String Apellido1) {
        this.Apellido1 = Apellido1;
    }

    @Override
    public String getApellido2() {
        return Apellido2;
    }

    @Override
    public void setApellido2(String Apellido2) {
        this.Apellido2 = Apellido2;
    }

 

    @Override
    public int compareTo(Object o) {
        Jugador otra = (Jugador) o;
        return this.nombre.compareToIgnoreCase(otra.nombre);
    }

    @Override
    public String toString() {
        return super.toString() + " " + sueldo + " " + media;
    }

}
