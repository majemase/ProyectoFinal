/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyectoprueba;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import javax.swing.JLabel;
import javax.swing.SwingUtilities;

/**
 *
 * @author alvar
 */
public class Liga implements Serializable {

    private List<Equipo> equipos = new ArrayList();

    public List<Equipo> getEquipos() {
        return equipos;
    }

    public void setEquipos(List<Equipo> equipos) {
        this.equipos = equipos;
    }

    public void guardarDatos() {
        try {
            ObjectOutputStream salida = new ObjectOutputStream(new FileOutputStream("liga.bin"));
            salida.writeObject(this);
            salida.close();
        } catch (IOException e) {
            System.out.println("Error al guardar los datos del liga: " + e.getMessage());
        }
    }

    public static Liga cargarDatos() {
        Liga liga = null;
        try {
            ObjectInputStream entrada = new ObjectInputStream(new FileInputStream("liga.bin"));
            liga = (Liga) entrada.readObject();
            entrada.close();
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("Error al cargar los datos de la liga: " + e.getMessage());
        }
        return liga;
    }

}
