/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyectoprueba;

import java.util.Comparator;

/**
 *
 * @author alvar
 */
public class ComparadorPorSueldo implements Comparator {

    @Override
    public int compare(Object o1, Object o2) {
        Jugador otro1 = (Jugador) o1;
        Jugador otro2 = (Jugador) o2;
        int devolver = 0;
        if (otro1.getSueldo() > otro2.getSueldo()) {
            devolver = -1;
        } else {
            devolver = 1;
        }
        return devolver;

    }
    

}


