/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyectoprueba;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.List;
import java.util.Random;

/**
 *
 * @author majemase
 */
public class Partido {
    
    private Equipo equipo1;
    private Equipo equipo2;
    private int golesEquipo1;
    private int golesEquipo2;

    public Partido(Equipo equipo1, Equipo equipo2, int golesEquipo1, int golesEquipo2) {
        this.equipo1 = equipo1;
        this.equipo2 = equipo2;
        this.golesEquipo1 = golesEquipo1;
        this.golesEquipo2 = golesEquipo2;
    }

    public Equipo getEquipo1() {
        return equipo1;
    }

    public void setEquipo1(Equipo equipo1) {
        this.equipo1 = equipo1;
    }

    public Equipo getEquipo2() {
        return equipo2;
    }

    public void setEquipo2(Equipo equipo2) {
        this.equipo2 = equipo2;
    }

    public int getGolesEquipo1() {
        return golesEquipo1;
    }

    public void setGolesEquipo1(int golesEquipo1) {
        this.golesEquipo1 = golesEquipo1;
    }

    public int getGolesEquipo2() {
        return golesEquipo2;
    }

    public void setGolesEquipo2(int golesEquipo2) {
        this.golesEquipo2 = golesEquipo2;
    }

    public static void guardarDatos(Partido partido) {
        try {
            ObjectOutputStream salida = new ObjectOutputStream(new FileOutputStream("partidos.bin",true));
            salida.writeObject(partido);
            } catch (IOException e) {
            System.out.println("Error al guardar los datos en el archivo: " );
            e.printStackTrace();
        }
    }

    public static Partido cargarDatos() {
        Partido partido = null;
        try {
            ObjectInputStream entrada = new ObjectInputStream(new FileInputStream("partidos.bin"));
            partido = (Partido) entrada.readObject();
           
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("Error al cargar los datos desde el archivo: " );
            e.printStackTrace();
        }
        return partido;
    }
    

    public String toString() {
        return equipo1 + ": " + golesEquipo1 + " - " + equipo2 + ": " + golesEquipo2;
    }

}
